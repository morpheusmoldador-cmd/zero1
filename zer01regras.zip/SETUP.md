# Hospedar o portal ZER01 na Square Cloud

O site **não depende do seu computador**. Depois do upload, ele fica no ar 24h na Square Cloud. Se o processo cair, a Square Cloud sobe de novo (`AUTORESTART=true`).

Textos, fotos, Loja VIP, admins e login ficam salvos no servidor da Square Cloud. Você só usa o navegador para editar.

## 1. App Discord (OAuth)

1. https://discord.com/developers/applications → **New Application**
2. Copie **Client ID** e **Client Secret**
3. Em **OAuth2 → Redirects**, cadastre:

```
https://zer01roleplay.livroderegras.app/auth/discord/callback
```

## 2. Enviar o zip

Arquivo: `zer01regras.zip`

1. Abra https://squarecloud.app
2. Crie uma aplicação **Website / Site** (não bot)
3. Envie o zip
4. Confirme memória **512 MB** (mínimo de site)

## 3. Variáveis no painel da Square Cloud

Não coloque isso no seu PC. Só no painel da aplicação:

| Variável | Valor |
|---|---|
| `PUBLIC_URL` | `https://zer01roleplay.livroderegras.app` |
| `DISCORD_CLIENT_ID` | Client ID |
| `DISCORD_CLIENT_SECRET` | Client Secret |
| `OWNER_ID` | `1228740417839824968` |
| `SESSION_SECRET` | frase longa e aleatória |

Não defina `PORT`. O site já escuta a **porta 80**.

## 4. Depois de online

- Site público: `https://zer01roleplay.livroderegras.app`
- **Admin** → Discord (sua conta já é dona)
- **Editar**, **Loja VIP**, **Cadastros** — tudo no site, no ar
- Pode desligar o computador
