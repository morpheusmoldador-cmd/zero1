# Portal ZER01 Roleplay

Site oficial hospedado na **Square Cloud**. Não precisa deixar o PC ligado.

- Login Discord (dono: `1228740417839824968`)
- Pedidos de admin para aceitar/recusar
- Editor visual no próprio site
- Botão **LOJA VIP** com link colado por você
- Reinício automático se o processo cair

Envio: `npm run pack` → `zer01regras.zip` → painel Square Cloud.

Passo a passo: [SETUP.md](SETUP.md)
